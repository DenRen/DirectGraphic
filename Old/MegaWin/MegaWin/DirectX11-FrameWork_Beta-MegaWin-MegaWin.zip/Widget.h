#pragma once
class Widget
{
public:

	//virtual void Initialize ();
	virtual void Update ()
	{};
	virtual void Draw ()
	{};

	// Mouse and keyboard
};

